const API_BASE = 'http://localhost:5000/api';

// Redirect to login when trying to access deals
function redirectToLogin() {
    window.location.href = 'login.html';
}

// Form handling
document.addEventListener('DOMContentLoaded', function() {
    // Login form handling
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            try {
                const response = await fetch(${API_BASE}/auth/login, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ email, password })
                });

                const data = await response.json();

                if (response.ok) {
                    localStorage.setItem('token', data.token);
                    localStorage.setItem('user', JSON.stringify(data.data.user));
                    
                    alert('Login successful! Redirecting to dashboard...');
                    window.location.href = 'dashboard.html';
                } else {
                    alert(data.errors[0].msg);
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Login failed. Please try again.');
            }
        });
    }
    
    // Registration form handling
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const fullName = document.getElementById('fullName').value;
            const email = document.getElementById('regEmail').value;
            const password = document.getElementById('regPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            if (password !== confirmPassword) {
                alert('Passwords do not match');
                return;
            }
            
            try {
                const response = await fetch(${API_BASE}/auth/register, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ 
                        name: fullName, 
                        email, 
                        password 
                    })
                });

                const data = await response.json();

                if (response.ok) {
                    localStorage.setItem('token', data.token);
                    localStorage.setItem('user', JSON.stringify(data.data.user));
                    
                    alert('Registration successful! Welcome to Affiliat.co.in');
                    window.location.href = 'dashboard.html';
                } else {
                    alert(data.errors[0].msg);
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Registration failed. Please try again.');
            }
        });
    }
    
    // Check if user is logged in
    async function checkAuth() {
        const token = localStorage.getItem('token');
        if (!token && window.location.pathname.includes('dashboard.html')) {
            window.location.href = 'login.html';
            return;
        }

        if (token) {
            try {
                const response = await fetch(${API_BASE}/auth/me, {
                    headers: {
                        'Authorization': Bearer ${token}
                    }
                });

                if (!response.ok) {
                    localStorage.removeItem('token');
                    localStorage.removeItem('user');
                    if (window.location.pathname.includes('dashboard.html')) {
                        window.location.href = 'login.html';
                    }
                }
            } catch (error) {
                console.error('Auth check failed:', error);
            }
        }
    }
    
    checkAuth();
});

// Logout function
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = 'index.html';
}

// Get current user
function getCurrentUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
}